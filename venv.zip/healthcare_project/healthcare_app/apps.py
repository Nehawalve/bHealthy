from django.apps import AppConfig


class HealthcareAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'healthcare_app'
